from django.contrib import admin
from .models import WebcamImage, Attendance

admin.site.register(WebcamImage)
admin.site.register(Attendance)
