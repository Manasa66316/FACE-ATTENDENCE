from django.contrib import admin
from .models import PersonType, FaceDB

admin.site.register(PersonType)
admin.site.register(FaceDB)

