from django.apps import AppConfig


class FacedbConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'facedb'
